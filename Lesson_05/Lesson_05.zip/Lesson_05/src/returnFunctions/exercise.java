package returnFunctions;

/*
Lesson _05
In this exercise, you will use return functions to calculate the slope between 2 points and the distance between 2 points

If the variable var is equal to 1 then calculate the distance between 2 points
Else If variable var is equal to 2 then calculate the slope between 2 points
Else var does not have an appropriate value.

Good Luck Completing the exercise!
*/

/*
 * @author Surya
 */

public class exercise
{
	public static void main(String[]args)
	{
		int var = 1;
		double x1 = 1;
		double y1 = 1;
		double x2 = 5;
		double y2 = 1;
		
	}
	
	static void calcDist()//make sure you enter parameters
	{
		
	}
	
	static void calcSlope()//make sure you enter parameters
	{
		
	}
}
