package team3647robotPackage;

import edu.wpi.first.wpilibj.Encoder;

public class Encoders 
{		

}
