package exampleTwo;

/*
Lesson _06
In this exercise, you will use classes to create a simple calculator
The operation you will be performing will depend on the run variable
For this exercise please create your classes are not in the same file but in the same package
Feel free to look at the example file while doing this exercise
Good luck!
 */

public class runFunction 
{
	public static void main(String[]args)
	{
		int run = 4;
		// 1 is addition
		// 2 is subtraction
		// 3 is multiplication
		// 4 is division
		
		//variables used for calculations
		double numOne = 34;
		double numTwo = 67;
		
		//make objects
		
		//run conditional statements using the run variable
	}

}
