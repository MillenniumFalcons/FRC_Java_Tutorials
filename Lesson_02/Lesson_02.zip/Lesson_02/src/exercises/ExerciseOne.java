package exercises;

/*
Lesson _02
In this exercise, you will use if, else if, and else statements to determine dedication of robotics members depending on build season hours
For example:
300+ hours: dedication level = "dedication on steroids"
200+ hours: dedication level = "very dedicated"
150+ hours: dedication level = "really dedicated"
120+ hours: dedication level = "dedicated"
90+ hours: dedication level = "average dedication"
50+ hours: dedication level = "un-dedicated"
else: dedication level = "Eamon"

Good Luck Completing the exercise!
*/

/*
 * @author Surya
 */

public class ExerciseOne 
{
	public static void main(String[] args) 
	{
		 int buildSeasonHours;
		 String dedicationLevel;
	}
}
