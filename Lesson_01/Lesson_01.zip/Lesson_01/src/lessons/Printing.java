package lessons;

/*
Lesson _01
In this lesson we will learn how to print in java
The print function is used to display data on the java console
Here is an Example
 */

/*
 * @author Surya
 */

public class Printing 
{

    public static void main(String[] args) 
    {
        System.out.println("Welcome to programming!!!");
    }
    
}