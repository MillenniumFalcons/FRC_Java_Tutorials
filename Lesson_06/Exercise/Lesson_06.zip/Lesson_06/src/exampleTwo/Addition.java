package exampleTwo;

public class Addition 
{
	/*
	* Make necessary variables
	* Make a constructor for that class
	* Make a function called performOperation() that returns the sum of both the numbers 
	*/
}
