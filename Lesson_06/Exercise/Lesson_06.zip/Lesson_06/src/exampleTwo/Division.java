package exampleTwo;

public class Division 
{
	/*
	* Make necessary variables
	* Make a constructor for that class
	* Make a function called performOperation() that returns the quotient of both the numbers 
	*/
}
