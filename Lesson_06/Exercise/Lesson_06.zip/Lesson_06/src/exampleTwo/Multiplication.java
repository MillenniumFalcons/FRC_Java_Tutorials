package exampleTwo;

public class Multiplication 
{
	/*
	* Make necessary variables
	* Make a constructor for that class
	* Make a function called performOperation() that returns the product of both the numbers 
	*/

}
