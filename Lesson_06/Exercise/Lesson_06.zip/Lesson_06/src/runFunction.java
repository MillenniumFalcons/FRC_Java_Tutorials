/*
Lesson _06
In this exercise, you will use classes to create a simple calculator
The operation you will be performing will depend on the run variable
For this exercise please create all your classes in one file
Feel free to look at the example file while doing this exercise
Good luck!
 */

public class runFunction 
{
	public static void main(String[]args)
	{
		int run = 4;
		// 1 is addition
		// 2 is subtraction
		// 3 is multiplication
		// 4 is division
		
		//variables used for calculations
		double numOne = 34;
		double numTwo = 67;
		
		//make objects
		
		//run conditional statements using the run variable
	}

}

/*
 Make a class called Addition
 * Make necessary variables
 * Make a constructor for that class
 * Make a function called performOperation() that returns the sum of both the numbers 
 */

/*
Make a class called Subtraction
* Make necessary variables
* Make a constructor for that class
* Make a function called performOperation() that returns the difference of both the numbers 
*/

/*
Make a class called Multiplication
* Make necessary variables
* Make a constructor for that class
* Make a function called performOperation() that returns the product of both the numbers 
*/

/*
Make a class called Division
* Make necessary variables
* Make a constructor for that class
* Make a function called performOperation() that returns the quotient of both the numbers 
*/
