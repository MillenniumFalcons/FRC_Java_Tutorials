package exampleTwo;

public class Subtraction 
{
	/*
	* Make necessary variables
	* Make a constructor for that class
	* Make a function called performOperation() that returns the sum of difference the numbers 
	*/
}
